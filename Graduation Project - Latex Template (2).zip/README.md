# Gebze Technical University Thesis: LaTeX Template

This a student-made template following the thesis template guidelines of Gebze Technical University.
